
#include <stdlib.h>
#include "lib.h"
int main(){
   abdurashid("Hello World");
   exit(0);
}
