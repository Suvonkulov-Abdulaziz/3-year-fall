#include <stdio.h>
void abdurashid(char* arg){
	printf("salom %s\n", arg);
}
