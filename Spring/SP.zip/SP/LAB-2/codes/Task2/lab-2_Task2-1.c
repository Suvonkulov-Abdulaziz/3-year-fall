
#include <stdio.h>
void abzal(int arg){
	printf("salom %d\n", arg);
}

