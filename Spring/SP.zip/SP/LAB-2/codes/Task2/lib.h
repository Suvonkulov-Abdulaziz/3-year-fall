void abzal(int arg);
void abdurashid(char* arg);
