#ifndef YOURNAME_MATRIX_H
#define YOURNAME_MATRIX_H

void YourName_Get(double Mat[][3]);
void YourName_Show(double Mat[][3]);
void YourName_Add(double MatA[][3], double MatB[][3], double MatC[][3]);
void YourName_Mul(double MatA[][3], double MatB[][3], double MatC[][3]);
void YourName_Inv(double MatA[][3], double MatB[][3]);
double YourName_Mod(double MatA[][3]);

#endif

