
echo -n "Enter to count: "
read input

echo "$input" | wc -m
exit 0
